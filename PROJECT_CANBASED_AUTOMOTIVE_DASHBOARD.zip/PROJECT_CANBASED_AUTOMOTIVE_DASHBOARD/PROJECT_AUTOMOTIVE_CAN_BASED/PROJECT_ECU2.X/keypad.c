
#include <xc.h>
char flag=1;
char read_keypad()
{
    if((PORTC&0x0F) !=0x0F && flag)
    {
        flag=0;
        return PORTC&0x0F;
    }
    else if((PORTC&0x0F) ==0x0F)
    {
        flag=1;
    }
    return 0x0F;
}